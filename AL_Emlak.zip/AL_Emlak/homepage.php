<?php 
$title = "الصفحة الرئيسية";
$header_title = "العملاق";
include 'header.php';
//include 'messages.php'; 
?>
<?php
$message1 = 'سيتم عرض صفحة الخدمات';
?>
	<section>
		<h2>أهلاً بك في موقعنا!</h2>
		<p>نحن نقدم أفضل خدمات الطاقة الشمسية والكهربائية التي تلبي احتياجات عملائنا.</p>
		<?php 
		$pages = ['services.php', 'about.php', 'contact.php'];
		for ($i = 0; $i < count($pages); $i++) { 
		echo "<a href='{$pages[$i]}' onclick='showPage({$i})'>اضغط هنا</a>"; 
		}
		?>  
	</section>
	<script>
	function showAlert(message) {
	alert(message); 
	}
	
	function showServices() { 
	showAlert(<?php echo $message1; ?>); 
	}
    </script> 

<?php
include 'footer.php'; 
?>