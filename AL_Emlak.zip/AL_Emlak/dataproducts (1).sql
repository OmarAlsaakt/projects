
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dataproducts`
--

-- --------------------------------------------------------

--
-- بنية الجدول `messages`
--

CREATE TABLE `messages` (
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `messages`
--

INSERT INTO `messages` (`name`, `email`, `message`) VALUES
('omar', 'omarali@gmail.com', 'jkdwiuhueudiue'),
('omar', 'omarali@gmail.com', 'hfhiuplklklksaoioikjreiuou45ljnfkhoi43jqi;oirqnkreoiernrmfhh4iuu54iubgfmjfkjakj'),
('salman', 'almjydyslman2@gmail.com', 'اريد منظومة متكاملة لمشروع مياه '),
('omar', 'omarali@gmail.com', 'خهخه'),
('ali', 'almjydyslman2@gmail.com', 'igfcdcrdvbvghhvfcfcx'),
('omar', 'omarali@gmail.com', 'jyjyu5trhhr');

-- --------------------------------------------------------

--
-- بنية الجدول `products`
--

CREATE TABLE `products` (
  `id` int(6) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `table` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`table`)),
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `image`, `table`, `price`) VALUES
(7, 'غسالات', 'ALPHA,HYUNDAI,KELON', 'C:xampphtdocsphpimageIMG-20221212-WA0006.jpg', '[[\"اللون\", \"أحمر\"], [\"الحجم\", \"كبير\"], [\"الشكل\", \"مستطيل\"]]', '170.00'),
(8, 'منتج 1', 'وصف المنتج 1', 'https://example.com/image1.jpg', '[[\"اللون\", \"أحمر\"], [\"الحجم\", \"كبير\"], [\"الشكل\", \"مستطيل\"]]', '99.99'),
(9, 'منتج 2', 'وصف المنتج 2', 'https://example.com/image2.jpg', '[[\"اللون\", \"أخضر\"], [\"الحجم\", \"صغير\"], [\"الشكل\", \"مربع\"]]', '49.99'),
(10, 'منتج 3', 'وصف المنتج 3', 'https://example.com/image3.jpg', '[[\"اللون\", \"أزرق\"], [\"الحجم\", \"كبير\"], [\"الشكل\", \"مستطيل\"]]', '149.99'),
(11, 'منتج 4', 'وصف المنتج 4', 'https://example.com/image1.jpg', '[[\"اللون\", \"أحمر\"], [\"الحجم\", \"كبير\"], [\"الشكل\", \"مستطيل\"]]', '99.99'),
(12, 'منتج 5', 'وصف المنتج 5', 'https://example.com/image2.jpg', '[[\"اللون\", \"أخضر\"], [\"الحجم\", \"صغير\"], [\"الشكل\", \"مربع\"]]', '49.99'),
(13, 'منتج 6', 'وصف المنتج 6', 'https://example.com/image3.jpg', '[[\"اللون\", \"أزرق\"], [\"الحجم\", \"كبير\"], [\"الشكل\", \"مستطيل\"]]', '149.99'),
(14, 'منتج 7', 'وصف المنتج 7', 'https://example.com/image1.jpg', '[[\"اللون\", \"أحمر\"], [\"الحجم\", \"كبير\"], [\"الشكل\", \"مستطيل\"]]', '99.99'),
(15, 'منتج 8', 'وصف المنتج 8', 'https://example.com/image2.jpg', '[[\"اللون\", \"أخضر\"], [\"الحجم\", \"صغير\"], [\"الشكل\", \"مربع\"]]', '49.99'),
(16, 'منتج 9', 'وصف المنتج 9', 'https://example.com/image3.jpg', '[[\"اللون\", \"أزرق\"], [\"الحجم\", \"كبير\"], [\"الشكل\", \"مستطيل\"]]', '149.99');

-- --------------------------------------------------------

--
-- بنية الجدول `users`
--

CREATE TABLE `users` (
  `id` int(6) UNSIGNED NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES
(1, 'omar', 'omarali@gmail.com', '5555'),
(2, 'omar', 'omarali@gmail.com', '33333'),
(3, 'abood', 'abood@gmail.com', '44444'),
(4, 'salman', 'omarali@gmail.com', '8888'),
(5, 'ali', 'omarali@gmail.com', '444'),
(6, 'ali', 'omarali@gmail.com', '----'),
(7, 'ali', 'omarali@gmail.com', 'omar59'),
(8, 'ali', 'omarali@gmail.com', 'omar59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
