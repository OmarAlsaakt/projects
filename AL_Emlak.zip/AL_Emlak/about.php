<?php 
	// تعريف المتغيرات
	$title = "عن الشركة";
	$header_title = "العملاق";
	$image_src = "image/IMG-20221219-WA0072.jpg";
	$description = "نحن شركة متخصصة في تصميم وتركيب أنظمة الطاقة الشمسية للمنازل والمباني التجارية والصناعية.";
	$num_customers = 500;
	$num_projects = 200;
	$num_countries = 10;
?>

<!DOCTYPE html>
<html lang="ar">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title><?php echo $title; ?></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
	<link rel="stylesheet"href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-1ZuIwKqh1gBC9eP8h4iG3zz8O4jz0jX6sP3SwR+8Dy9+6pHrK9UeNkF7fJg6GzjWq1n0IbIb2zZS5nN2mDZlHg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" integrity="sha512-4YRvEI6q7Sf4R8u8mZuvU6C7lQJd/3J4MnYfN9SxJ7uQ6oC0z/8MAJcQ6nK6fH2Ez7+C4NtQJNtoz5hYUJm5Kg==" crossorigin="anonymous" referrerpolicy="no-referrer" /> -->
	<link rel="stylesheet" href="style.css">
	<style>
	.bg-light {
    background-color: #812802!important;
    }
		header {
			background-color: #812802;
			color: #fff;
			padding: 20px;
			text-align: center;
		}
		
		nav {
			display: inline-block;
			margin-top:10px;
		}
		
		nav ul {
			list-style: none;
			margin: 0;
			padding: 0;
			text-align: center;
		}
		
		nav ul li {
			display: inline-block;
			margin: 0 10px;
		}
		
		nav ul li a {
			color: #fff;
			text-decoration: none;
		}
	</style>
</head>
<body>
	<header >
	<?php include "header.php"; ?>
	</header>
	<main class="container py-5">
		<section>
			<div class="row">
				<div class="col-md-6 mb-3">
					<img class="img-fluid" src="<?php echo $image_src; ?>" alt="صورة لوحدات شمسية" data-aos="fade-right" onmouseover="this.style.filter='grayscale(100%)';" onmouseout="this.style.filter='';">
				</div>
				<div class="col-md-6">
					<h2>من نحن</h2>
					<p><?php echo $description; ?></p>
					<h3 class="mt-5">إحصائيات الشركة:</h3>
					<ul class="list-unstyled mt-3">
						<li>
							<h4>عدد العملاء</h4>
							<p onclick="changeBackgroundColor(this)" class="bg-warning p-2"><?php echo $num_customers; ?></p>
						</li>
						<li>
							<h4>عدد المشاريع</h4>
							<p onclick="changeBackgroundColor(this)" class="bg-warning p-2"><?php echo $num_projects; ?></p>
						</li>
						<li>
							<h4>عدد المحافظات التي نخدمها</h4>
							<p onclick="changeBackgroundColor(this)" class="bg-warning p-2"><?php echo $num_countries; ?></p>
						</li>
					</ul>
				</div>
			</div>
		</section>
	</main>
	<script>
		function changeBackgroundColor(element) {
			element.classList.toggle("bg-danger");
		}
	</script>
	<?php
    include 'footer.php'; 
    ?>
</body>
</html>