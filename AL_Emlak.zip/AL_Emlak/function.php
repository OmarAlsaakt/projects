<?php
function display_services($services) {
?>
<div class="services">
  <?php foreach ($services as $service) : ?>
    <div class="service">
      <h3><?= $service[0] ?></h3>
      <img src="<?= $service[2] ?>" alt="<?= $service[1] ?>">
      <p><?= $service[1] ?></p>
    </div>
  <?php endforeach; ?>
</div>
<?php
}
?>
<?php
function display_products($products) {
  // عرض كل منتج على حدة
  foreach ($products as $product) {
      echo '
          <div class="product">
              <img src="images/' . $product['image'] . '">
              <h3>' . $product['name'] . '</h3>
              <p>' . $product['price'] . '</p>
              <p>' . $product['description'] . '</p>
              <button>إضافة إلى السلة</button>
          </div>
      ';
  }
  echo '</div>';
}

?>
