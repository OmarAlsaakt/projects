
<!DOCTYPE html>
<html lang="en">
<head>
<title>صفحة التسجيل الجديدة</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>
body {
background-color:#000000;
color: #333;
}
.container {
    background-color: #ffffff;
    border: 2px solid #cccccc;
    border-radius: 5px;
    box-shadow: 0px 0px 10px #cccccc;
    margin: 0 auto;
    max-width: 500px;
    padding: 20px;
    text-align: center;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
      /* animation: rotate 2s linear infinite; */
    box-shadow: 0 0 0 0 rgba(0, 123, 255, 0.7);
    animation: pulse 2s infinite;
}
@keyframes pulse {
0% {
    box-shadow: 0 0 0 0 rgba(0, 123, 255, 0.7);
}
70% {
    box-shadow: 0 0 0 20px rgba(0, 123, 255, 0);
}
100% {
    box-shadow: 0 0 0 0 rgba(0, 123, 255, 0);
}
}
</style>
</head>
<body>
<div class="container">
    <h2>انشاء حساب جديد</h2>
    <form method="POST" action="send.php">
    <div class="form-group">
        <label for="name">الاسم الكامل:</label>
        <input type="text" class="form-control" id="name" name="name" placeholder="ادخل الاسم الكامل">
    </div>
    <div class="form-group">
        <label for="email">البريد الالكتروني:</label>
        <input type="email" class="form-control" id="email" name="email" placeholder="ادخل البريد الالكتروني">
    </div>
    <div class="form-group">
        <label for="password">كلمة المرور:</label>
        <input type="password" class="form-control" id="password" name="password" placeholder="ادخل كلمة المرور">
    </div>
    <button type="submit" class="btn btn-primary">انشاء الحساب</button>
    </form>
</div>
</body>
</html>