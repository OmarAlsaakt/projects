<?php
// توصيل قاعدة البيانات
$servername = "localhost";
$username = "root";
$password = "";
$dbname ="dataProducts";
$conn = mysqli_connect($servername , $username, $password, $dbname);

// التحقق من الاتصال بقاعدة البيانات
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// استعلام قاعدة البيانات لاسترداد المنتجات
$sql = "SELECT * FROM products";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="ar">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>منتجاتنا</title>
	<!-- تحميل Bulma -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.9.3/css/bulma.min.css">
	<link rel="stylesheet" href="style.css">
</head>
<body>
<header>
	<?php include 'header.php';?>
</header>
	<main>
		<section>
			<div class="container">
				<h2 class="title is-2 has-text-centered">منتجاتنا</h2>
				<p class="subtitle is-5 has-text-centered">يوجد لدينا مجموعة متنوعة من المنتجات التي تلبي احتياجات عملائنا. يرجى الاطلاع على قائمة المنتجات أدناه:</p>

				<div class="columns is-multiline">
					<?php
						// Loop through products and create columns
						while ($product = mysqli_fetch_assoc($result)) {
							echo '<div class="column is-4">';
							echo '<div class="card">';
							echo '<div class="card-image">';
							echo '<figure class="image is-4by3">';
							echo '<img src="' . $product["image"] . '" alt="' . $product["name"] . '">';
							echo '</figure>';
							echo '</div>';
							echo '<div class="card-content">';
							echo '<h3 class="title is-4 has-text-centered">' . $product["name"] . '</h3>';
							echo '<div class="content">' . $product["description"] . '</div>';
							echo '<table class="table is-striped">';
							echo '<thead><tr><th>المنتج</th><th>السعر</th></tr></thead><tbody>';
							// تحويل الجدول النصي إلى مصفوفة
							$table = json_decode($product["table"], true);
							foreach ($table as $row) {
								echo '<tr><td>' . $row[0] . '</td><td>' . $row[1] . '</td></tr>';
							}
							echo '</tbody></table>';
							echo '<div class="has-text-centered">';
							echo '<a href="#" class="button is-primary">شراءالآن</a>';
							echo '</div>';
							echo '</div>';
							echo '</div>';
							echo '</div>';
						}
					?>
				</div>
			</div>
		</section>
	</main>
	<!--JavaScript-->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
	<?php
include 'footer.php'; 
?>
</body>
</html>
<?php// إغلاق اتصال قاعدة البيانات
mysqli_close($conn);
?> 
