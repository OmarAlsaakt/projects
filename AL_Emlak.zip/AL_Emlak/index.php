<?php
// Start the session
session_start();

//Check if user is already logged in
if (isset($_SESSION['email'])) {
    header('Location: homepage.php');
    exit();
  }
// Check if the user has a "remember me" cookie
if (isset($_COOKIE['email']) && isset($_COOKIE['password'])) {
    // Set the sessionمتغيرات
    $_SESSION['email'] = $_COOKIE['email'];
    $_SESSION['password'] = $_COOKIE['password'];
}

// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data
    $email = $_POST['email'];
    $password = $_POST['password'];
    $remember = isset($_POST['remember']) ? true : false;

    // Validate the form data
    if (!empty($email) && !empty($password)) {
        // Connect to the database
        $conn = new mysqli('localhost', 'root', '', 'dataproducts');
        if ($conn->connect_error) {
            die('Connection failed: ' . $conn->connect_error);
        }

        // Check if the username and password are correct
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND password = ?");
        $stmt->bind_param("ss", $email, $password);
        $stmt->execute();
        $result= $stmt->get_result();
        $user = $result->fetch_assoc();

        if ($user) {
            // Set the session variables
            $_SESSION['email'] = $user['email'];
            $_SESSION['password'] = $user['password'];

            // Set the cookie if "Remember me" is checked
            if ($remember) {
                setcookie('email', $user['email'], time() + (86400 * 30), "/");
                setcookie('password', $user['password'], time() + (86400 * 30), "/");
            }

            // Redirect to the dashboard page
            header('Location: homepage.php');
            exit;
        } else {
            // Display an error message
            echo "Invalid username or password.";
        }

        $stmt->close();
        $conn->close();
    } else {
        // Display an error message
        echo "Please enter a username and password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>العملاق باور</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <linkrel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
  body {
  background-color:#000000;
  color: #333;
}
  .container {
    background-color: #ffffff;
      border: 2px solid #cccccc;
      border-radius: 5px;
      box-shadow: 0px 0px 10px #cccccc;
      margin: 0 auto;
      max-width: 500px;
      padding: 20px;
      text-align: center;
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      /* animation: rotate 2s linear infinite; */
      box-shadow: 0 0 0 0 rgba(0, 123, 255, 0.7);
      animation: pulse 2s infinite;
}
/* @keyframes rotate {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
} */
@keyframes pulse {
  0% {
    box-shadow: 0 0 0 0 rgba(0, 123, 255, 0.7);
  }
  70% {
    box-shadow: 0 0 0 20px rgba(0, 123, 255, 0);
  }
  100% {
    box-shadow: 0 0 0 0 rgba(0, 123, 255, 0);
  }
}
.form-group {
  margin-bottom: 20px;
}

.form-control {
  width: 100%;
  height: 40px;
}
.form-control {
  border-radius: 0;
  border: 1px solid #ccc;
  font-family: Arial, sans-serif;
  font-size: 16px;
  line-height: 1.5;
}

label {
  font-size: 18px;
  font-weight: bold;
}

.form-group {
  position: relative;
}

.form-group label::after {
  content: '*';
  color: #e74c3c;
  margin-left: 5px;
}

.form-control:focus {
  outline: none;
  border-color: #66afe9;
  box-shadow: 0 0 8px rgba(102,175,233,.6);
}
.form-group::before {
  content: "";
  position: absolute;
  bottom: -8px;
  left: 0;
  width: 100%;
  height: 2px;
  background-color: #ccc;
  z-index: -1;
}

.form-group::after {
  content: "";
  position: absolute;
  bottom: -8px;
  left: 0;
  width: 0;
  height: 2px;
  background-color: #007bff;
  transition: width 0.3s ease;
  z-index: -1;
}

.form-control:focus ~ .form-group::after {
  width: 100%;
}
.btn-primary {
  background-color:#6f1d10;
  border-color: #007bff;
  color: #fff;
  font-size: 18px;
  font-weight: bold;
  padding: 10px 30px;
  border-radius: 0;
}

.btn-primary:hover, .btn-primary:focus {
  background-color: #0069d9;
  border-color: #0062cc;
  color: #fff;
}
.checkbox, .form-group:last-child {
  margin-bottom: 0;
}

.checkbox label {
  font-size: 16px;
}

.error-message, .success-message {
  font-size: 16px;
  margin-top: 10px;
}
  </style>
</head>
<body>
  <div class="container">
    <h2>تسجيل الدخول</h2>
    <form method="post">
      <div class="form-group">
        <label for="email">البريد الإلكتروني:</label>
        <input type="email" class="form-control" id="email" placeholder="أدخل البريد الإلكتروني" name="email">
      </div>
      <div class="form-group">
        <label for="pwd">كلمةالمرور:</label>
        <input type="password" class="form-control" id="pwd" placeholder="أدخل كلمة المرور" name="password">
      </div>
      <div class="form-group">
        <label>ليس لديك حساب؟ <a href="register.php">انشئ حسابًا جديدًا</a></label>
      </div>
      <div class="checkbox">
        <label><input type="checkbox" name="remember-me"> تذكرني</label>
      </div>
      <button type="submit" class="btn btn-primary">تسجيل الدخول</button>
      <div class="error-message" id="error-message"></div>
      <div class="success-message" id="success-message"></div>
    </form>
  </div>
</body>
</html>