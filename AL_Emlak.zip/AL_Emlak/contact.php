<?php
// تعريف المتغيرات الأساسية
$message_sent = false;
$errors = array();
$form_action = $_SERVER['PHP_SELF'];

// تحقق من إرسال النموذج
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // تحقق من صحة الحقول
    if (empty($_POST['name']) || empty($_POST['email']) || empty($_POST['message'])) {
        $errors[] = 'يرجى ملء جميع الحقول المطلوبة';
    } else {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $message = $_POST['message'];

        // توصيل قاعدة البيانات
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname ="dataProducts";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("فشل الاتصال: " . $conn->connect_error);
        }

        // إدخال البيانات في جدول الرسائل
        $sql = "INSERT INTO messages (name, email, message) VALUES ('$name', '$email', '$message')";

        if ($conn->query($sql) === TRUE) {
            $message_sent = true;
            $form_action = '';
        } else {
            $errors[] = 'حدث خطأ أثناء إرسال الرسالة: ' . $conn->error;
        }

        $conn->close();
    }
}
?>

<?php include 'header.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>اتصل بنا</title>
    <style>
		body {
			background-color: #f2f2f2;
			color: #333;
			font-family: Arial, sans-serif;
		}

		h1, h2 {
			color: #036;
		}

		input[type="submit"] {
			background-color: #036;
			color: #fff;
			padding: 10px 20px;
			border: none;
			border-radius: 5px;
			cursor: pointer;
		}

		input[type="submit"]:hover {
			background-color: #024;
		}

		label {
			display: block;
			margin-bottom: 5px;
			font-weight: bold;
		}

		form {
			max-width: 600px;
			margin: auto;
			padding: 20px;
			border: 1px solid #ccc;
			border-radius: 5px;
			box-shadow: 0 0 10px #ccc;
		}

		input[type="text"],
		input[type="email"],
		textarea {
			width: 100%;
			padding: 10px;
			border: 1px solid #ccc;
			border-radius: 5px;
			margin-bottom: 10px;
			box-sizing: border-box;
		}

		input:required:focus,
		input:invalid:focus,
		textarea:required:focus,
		textarea:invalid:focus {
			border-color: red;
		}

		input[type="email"]:valid {
			border-color: green;
		}

		ul {
			list-style: none;
			color: red;
			margin: 0;
			padding: 0;
		}

		ul li {
			margin-bottom: 5px;
		}

		h2 {
			color: green;
			font-size: 24px;
			margin-bottom: 20px;
		}

		#success-sound {
			display: none;
		}

		input[type="submit"]:active {
			background-color: #024;
			transform: translateY(1px);
		}
	</style>
        
</head>
<body>
    <?php if ($message_sent): ?>
        <h2>تم إرسال الرسالة بنجاح!</h2>
        <audio id="success-sound" src="success.wav"></audio>
    <?php else: ?>
        <?php if (!empty($errors)): ?>
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?php echo $error; ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>

        <form action="<?php echo $form_action; ?>" method="post" onsubmit="return confirmSubmit()">
            <label for="name">الاسم:</label><br>
            <input type="text" id="name" name="name" required><br>

            <label for="email">البريد الإلكتروني:</label><br>
            <input type="email" id="email" name="email" required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$"><br>

            <label for="message">الرسالة:</label><br>
            <textarea id="message" name="message" required></textarea><br>

            <input type="submit" value="إرسال">
        </form>

        <script>
            function confirmSubmit() {
                var result = confirm("هل أنت متأكد من إرسال الرسالة؟");
                if (result == true) {
                    return true;
                } else {
                    return false;
                }
            }

            var form = document.querySelector('form');
            var successSound = document.getElementById('success-sound');

            form.addEventListener('submit', function(event) {
                var formIsValid = form.checkValidity();

                if (!formIsValid) {
                    event.preventDefault();
                } else {
                    successSound.play();
                }
            });
            // الكود اللازم لإضافة صوت نجاح الإرسال
		var successSound = new Audio("success.mp3");
		var submitButton = document.querySelector("input[type='submit']");
		var successMessage = document.querySelector("#success-message");

		submitButton.addEventListener("click", function() {
			successSound.play();
			successMessage.style.display = "block";
		});
        </script>
    <?php endif; ?>
</body>
</html>

<?php include 'footer.php'; ?>