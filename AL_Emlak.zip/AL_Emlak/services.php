<!DOCTYPE html>
<html>
<head>
	<title>الخدمات</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" href="style.css">
	<style>
	body {
    background-color:#d5dce49e;
    /* color: #333; */
} 
	.services{
    background-color:#6c757d!important;
    border: 2px solid #cccccc;
    border-radius: 5px;
    box-shadow: 0px 0px 10px #cccccc;
    margin: 0 auto;
    max-width: 500px;
    padding: 20px;
    /* text-align: center;
    position: absolute; */
    /* top: 50%;
    left: 50%;
    transform: translate(-50%, -50%); */
      /* animation: rotate 2s linear infinite; */
    /* box-shadow: 0 0 0 0 rgba(0, 123, 255, 0.7); */
    /* animation: pulse 2s infinite; */
}
	</style>
</head>
<body>
	<?php
		$title = "الخدمات";
		$header_title = "العملاق باور - الخدمات";
		$image_src = "image/FB_IMG_1671475834616.jpg";
		$services = array(
		    array("منظومات متكاملة", "توفير منظومات شمسية وبديلة للعديد من مشاريع المياه", "image/images.jpg", "السعر: 100 دولار"),
		    array("خدمة 2", "وصف الخدمة 2", "$image_src", "السعر: 150 دولار"),
		    array("خدمة 3", "وصف الخدمة 3", "image3.jpg", "السعر: 200 دولار"),
		    array("خدمة 4", "وصف الخدمة 4", "image4.jpg", "السعر: 250 دولار")
		);
		include 'header.php';
	?>
	<section>
		<div class="container">
			<h2 class="text-center">الخدمات</h2>
			<div class="row justify-content-center">
				<?php 
				require 'function.php'; 
				display_services($services); 
				?>
			</div>
		</div>

		<div class="container-fluid bg-secondary text-white py-5">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<h2 class="text-center">العروض والتخفيضات</h2>
						<p class="text-center">تفقد الآن عروضنا وتخفيضاتنا الحصرية على المنتجات</p>
						<div class="text-center">
							<a href="#" class="btn btn-light">اضغط هنا للتفاصيل</a>
						</div>
					</div>
					<div class="col-md-4">
						<h2 class="text-center">مشاريعنا</h2>
						<p class="text-center">تفقد الآن بعض من مشاريعنا السابقة</p>
						<div class="text-center">
							<a href="#" class="btn btn-light">اضغط هنا للمزيد من التفاصيل</a>
						</div>
					</div>
					<div class="col-md-4">
						<h2 class="text-center">الدعم الفني</h2>
						<p class="text-center">تواصل مع فريق الدعم الفني لدينا للحصول على المساعدة اللازمة</p>
						<div class="text-center">
							<a href="contact.php" class="btn btn-light">تواصل معنا الآن</a>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="container py-5">
			<div class="row">
				<div class="col-md-6">
					<h2>آخر الأخبار والمقالات</h2>
					<p>تابع آخر الأخبار والمقالات الخاصة بشركتنا</p>
					<div class="text-center">
						<a href="#" class="btn btn-primary">اضغط هنا للمزيد من المقالات</a>
					</div>
				</div>
				<div class="col-md-6">
					<h2>تابعنا على وسائل التواصل الاجتماعي</h2>
					<ul class="list-unstyled">
						<li><a href="#">فيس بوك</a></li>
						<li><a href="#">تويتر</a></li>
						<li><a href="#">إنستجرام</a></li>
						<li><a href="#">يوتيوب</a></li>
					</ul>
				</div>
			</div>
		</div>

		<div class="container py-5">
			<div class="row">
				<div class="col-md-6">
					<h2>الأسئلة الشائعة</h2>
					<p>تفقد الآن الأسئلة الشائعة والإجابات الخاصة بها</p>
					<div class="text-center">
						<a href="#" class="btn btn-primary">اضغط هنا للمزيد من الأسئلة الشائعة</a>
					</div>
				</div>
				<div class="col-md-6">
					<h2>التوظيف</h2>
					<p>انضم إلى فريقنا واستكشف فرص العمل لدينا</p>
					<div class="text-center">
						<a href="#" class="btn btn-primary">اضغط هنا لمعرفة المزيد عن فرص العمل</a>
					</div>
				</div>
			</div>
		</div>

		<div class="container-fluid bg-dark text-white py-3">
			<div class="container">
				<div class="row">
					<div class="col-md-6">
						<img class="img-fluid" src="<?php echo $image_src; ?>" alt="صورة لوحدات شمسية" data-aos="fade-right" onmouseover="this.style.filter='grayscale(100%)';" onmouseout="this.style.filter='';">
					</div> 
					<div class="col-md-6">
						<ul class="list-inline text-right">
							<li class="list-inline-item"><a href="homepage.php">الرئيسية</a></li>
							<li class="list-inline-item"><a href="about.php">عن الشركة</a></li>
							<li class="list-inline-item"><a href="product.php">الخدمات</a></li>
							<li class="list-inline-item"><a href="#">المشاريع</a></li>
							<li class="list-inline-item"><a href="#">الأخبار والمقالات</a></li>
							<li class="list-inline-item"><a href="contact.php">اتصل بنا</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	<footer>
		<?php 
		include 'footer.php'; 
		?>
    </footer>
</body>
</html>
