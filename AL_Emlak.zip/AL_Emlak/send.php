<?php
// الاتصال بقاعدة البيانات
$server = "localhost";
$username = "root";
$password = "";
$database = "dataproducts";
$conn = new mysqli($server, $username, $password, $database);

// التحقق من عدم وجود أخطاء في الاتصال
if ($conn->connect_error) {
    die("فشل الاتصال بقاعدة البيانات: " . $conn->connect_error);
}

// استقبال البيانات من النموذج
$name = $_POST["name"];
$email = $_POST["email"];
$password = $_POST["password"];


// التحقق من وجود بيانات الاسم، البريد الإلكتروني وكلمة المرور
if (empty($name) || empty($email) || empty($password)) {
    echo "الرجاء إدخال جميع الحقول!";
} else {
    // عملية إضافة الحساب إلى قاعدة البيانات
    $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, é$password);
    if ($stmt->execute()) {
        echo "تم تسجيل الحساب بنجاح!";
        header("Location: homepage.php");
    } else {
        echo "حدث خطأ أثناء تسجيل الحساب، يرجى المحاولة مرة أخرى.";
    }
    $stmt->close();
}

$conn->close();

?>