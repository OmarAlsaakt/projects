<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title; ?></title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<style>
		header {
			background-color: #812802;
			color: #fff;
			padding: 20px;
			text-align: center;
		}
		
		nav {
			display: inline-block;
			margin-top: 20px;
		}
		
		nav ul {
			list-style: none;
			margin: 0;
			padding: 0;
			text-align: center;
		}
		
		nav ul li {
			display: inline-block;
			margin: 0 10px;
		}
		
		nav ul li a {
			color: #fff;
			text-decoration: none;
		}
		section {
			margin: 50px auto;
			max-width: 800px;
			text-align: center;
		}
		
		section h2 {
			font-size: 36px;
			margin-bottom: 20px;
		}
		
		section p {
			font-size: 18px;
			line-height: 30px;
			margin-bottom: 30px;
		} 		
		section img {
			max-width: 100%;
			height: auto;
			margin-bottom: 30px;
		} */
		
		section h3 {
			font-size: 24px;
			margin-bottom: 20px;
		}
		
		section ul {
			list-style: none;
			margin: 0;
			padding: 0;
			display: flex;
			justify-content: space-between;
			align-items: center;
			flex-wrap: wrap;
		}
		
		section ul li {
			flex-basis: 30%;
			margin-bottom: 20px;
			background-color: #f9f9f9;
			padding: 20px;
			box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.2);
		}
		
		section ul li h4 {
			font-size: 18px;
			margin-bottom: 10px;
			text-align: center;
		}
		
		section ul li p {
			font-size: 14px;
			line-height: 20px;
			margin: 0;
			text-align: center;
		
		}
		
		section a {
			display: inline-block;
			background-color: #972e02;
			color: #fff;
			padding: 10px 20px;
			border-radius: 5px;
			text-decoration: none;
			font-size: 18px;
			transition: background-color 0.3s ease;
		}
		
		section a:hover {
			background-color: #555;
		}
		/* section table {
			border-collapse: collapse;
			width: 100%;
			margin-bottom: 30px;
		}
		
		section table th, section table td {
			padding: 10px;
			border: 1px solid #ccc;
			text-align: center;
		}
		
		section table th {
			background-color: #f9f9f9;
		}
		
		section table tr:nth-child(even) {
			background-color: #f2f2f2;
		} */
		section form {
			margin-top: 30px;
			text-align: right;
		}
		
		section label {
			display: block;
			font-size: 18px;
			margin-bottom: 10px;
		}
		
		section input[type="text"],
		section input[type="email"],
		section textarea {
			width: 100%;
			padding: 10px;
			font-size: 16px;
			margin-bottom: 20px;
			border: 1px solid #ccc;
			border-radius: 4px;
			box-sizing: border-box;
		}
		
		section textarea {
			height: 150px;
		}
		
		section input[type="submit"] {
			background-color: #333;
			color: #fff;
			border: none;
			padding: 10px 20px;
			font-size: 16px;
			cursor: pointer;
			border-radius: 4px;
		}
		footer {
			background-color: #772701;
			color: #fff;
			padding: 15px;
			text-align: center;
			position: relative;
			width: 100%;
			bottom: 0;
		}
		
		footer p {
			margin: 0;
		}
	</style>
</head>
<?php
$header_title = "العملاق";
?>
	<header>
		<h1><?php echo $header_title; ?></h1>
		<nav>
			<ul>
				<li><a href="homepage.php">الصفحة الرئيسية</a></li>
				<li><a href="product.php">المنتجات</a></li>
				<li><a href="services.php">الخدمات</a></li>
				<li><a href="about.php">عن الشركة</a></li>
				<li><a href="contact.php">اتصل بنا</a></li>
				<li><a href="logout.php">تسجيل الخروج</a></li>
			</ul>
		</nav>
	</header>
	<main>
		<!-- يمكن إضافة المحتوى الرئيسي هنا -->
	</main>
</body>
</html>
