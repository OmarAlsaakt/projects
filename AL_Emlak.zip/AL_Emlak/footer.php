<!DOCTYPE html>
<html>
<head>
	<title>تفاعلات مع حقوق النشر</title>
	<style>
		footer p:hover {
			color: red;
			cursor: pointer;
		}

		#copyright-notice {
			display: none;
			background-color: #444;
			color: #fff;
			padding: 10px;
			position: absolute;
			top: 0;
			right: 0;
			z-index: 999;
		}
	</style>
</head>
<body>
	<footer>
		<p onclick="showCopyright()">حقوق النشر &copy; <?php echo date("Y"); ?> العملاق</p>
		<div id="copyright-notice">
			<p>جميع الحقوق محفوظة &copy; <?php echo date("Y"); ?> العملاق</p>
		</div>
	</footer>

	<script>
		function showCopyright() {
			var notice = document.getElementById("copyright-notice");
			notice.style.display = "block";
			setTimeout(function() {
				notice.style.display = "none";
			}, 3000);
		}
	</script>
</body>
</html>
